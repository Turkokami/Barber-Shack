# KEYSTONE SECURITY UPDATE: how to apply

1. Open your Keystone master file.
2. Paste everything below the line in `KEYSTONE-SECURITY-AMENDMENT.md` into it, near
   the top (with your other amendments or governing rules).
3. Put the `security-kit/` folder alongside Keystone, or in each project repo,
   so the builder can open the files the amendment points to.
4. Fill in the one `<…>` line (which stack add-ons apply) per project.
